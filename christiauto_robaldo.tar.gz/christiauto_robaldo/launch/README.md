Launch Files
============

Every team needs to have a launch file named (all lowercase): `team_name.launch`.

