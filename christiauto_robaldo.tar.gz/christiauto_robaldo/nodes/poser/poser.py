#!/usr/bin/env python

import rospy
from geometry_msgs.msg import Pose2D

def _handle_desired_position(msg):
	pass

def main():
	rospy.init_node('poser', anonymous=False)

	rospy.Subscriber('desired_position', Pose2D, _handle_desired_position)
	pub = rospy.Publisher('poser_position', Pose2D, queue_size=10)
	
	rate = rospy.Rate(100)
	while not rospy.is_shutdown():
		msg = Pose2D()
		msg.x = 0
		msg.y = 0
		msg.theta = 0
		pub.publish(msg)

		rate.sleep()

if __name__ == '__main__':
	main()